def solution(n):
    sum = 0
    for i in range(1, 1+n):
        sum += i
    return sum